<?php 
include 'php/config.php';
session_start();
$user_id = $_SESSION['unique_id']; // Assurez-vous que c'est correct

if (!isset($user_id)) {
    header('location: login.php');
    exit();
}

$select = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = '$user_id'");
if (mysqli_num_rows($select) > 0) {
    $row = mysqli_fetch_assoc($select);
} else {
    echo "Utilisateur introuvable.";
    exit();
}

if (isset($_POST['update_profile'])) {
    $alert = [];
    
    // Nettoyer et valider les entrées
    $update_fname = mysqli_real_escape_string($conn, trim($_POST['update_fname']));
    $update_lname = mysqli_real_escape_string($conn, trim($_POST['update_lname']));
    $update_email = mysqli_real_escape_string($conn, trim($_POST['update_email']));

    // Mise à jour du prénom
    if (!empty($update_fname)) {
        $update_nm = mysqli_query($conn, "UPDATE users SET fname = '$update_fname' WHERE unique_id = '$user_id'");
        if ($update_nm) {
            $alert[] = "Prénom mis à jour avec succès !";
        }
    }

    // Mise à jour du nom de famille
    if (!empty($update_lname)) {
        $update_nm = mysqli_query($conn, "UPDATE users SET lname = '$update_lname' WHERE unique_id = '$user_id'");
        if ($update_nm) {
            $alert[] = "Nom de famille mis à jour avec succès !";
        }
    }

    // Validation et mise à jour de l'email
    if (filter_var($update_email, FILTER_VALIDATE_EMAIL)) {
        $update_email_query = mysqli_query($conn, "UPDATE users SET email = '$update_email' WHERE unique_id = '$user_id'");
        if ($update_email_query) {
            $alert[] = "Email mis à jour avec succès !";
        }
    } else {
        $alert[] = "$update_email n'est pas une email valide !";
    }

    // Téléchargement de l'image
    if (isset($_FILES['update_image']) && $_FILES['update_image']['error'] == UPLOAD_ERR_OK) {
        $image = $_FILES['update_image']['name'];
        $image_size = $_FILES['update_image']['size'];
        $image_tmp_name = $_FILES['update_image']['tmp_name'];
        $image_folder = 'php/images/' . basename($image);

        if ($image_size > 2000000) {
            $alert[] = "La taille de l'image est trop grande !";
        } elseif (!getimagesize($image_tmp_name)) {
            $alert[] = "Le fichier téléchargé n'est pas une image !";
        } else {
            $update_img = mysqli_query($conn, "UPDATE users SET img = '$image' WHERE unique_id = '$user_id'");
            if ($update_img && move_uploaded_file($image_tmp_name, $image_folder)) {
                $alert[] = "Image mise à jour avec succès !";
            }
        }
    }
  
}
// Mise à jour du mot de passe
$main_pass = $row['password'];
$old_pass = isset($_POST['old_pass']) ? mysqli_real_escape_string($conn, trim($_POST['old_pass'])) : '';
$new_pass = isset($_POST['new_pass']) ? mysqli_real_escape_string($conn, trim($_POST['new_pass'])) : '';
$confirm_pass = isset($_POST['confirm_pass']) ? mysqli_real_escape_string($conn, trim($_POST['confirm_pass'])) : '';

if (!empty($old_pass) || !empty($new_pass) || !empty($confirm_pass)) {
    // Vérification avec MD5
    if (md5($old_pass) !== $main_pass) {
        $alert[] = "L'ancien mot de passe ne correspond pas !";
    } elseif ($new_pass !== $confirm_pass) {
        $alert[] = "La confirmation du mot de passe ne correspond pas !";
    } else {
        $hashed_pass = md5($new_pass); // Hachage du nouveau mot de passe avec MD5
        $update_pass = mysqli_query($conn, "UPDATE users SET password = '$hashed_pass' WHERE unique_id = '$user_id'");
        if ($update_pass) {
            $alert[] = "Mot de passe mis à jour avec succès !";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl.css">
    <title>Mettre à jour le profil</title>
</head>
<body>
    <div class="update-profile">
        <form action="" method="post" enctype="multipart/form-data">
            <img src="php/images/<?php echo htmlspecialchars($row['img']); ?>" alt="">
            <?php 
            if (isset($alert)) {
                foreach ($alert as $message) {
                    echo '<div class="alert">' . htmlspecialchars($message) . '</div>';
                }
            }
            ?>
            <div class="flex">
                <div class="inputBox">
                    <span>Prénom :</span>
                    <input type="text" name="update_fname" value="<?php echo htmlspecialchars($row['fname']); ?>" class="box">
                    <span>Nom de famille :</span>
                    <input type="text" name="update_lname" value="<?php echo htmlspecialchars($row['lname']); ?>" class="box">
                    <span>Votre Email :</span>
                    <input type="email" name="update_email" value="<?php echo htmlspecialchars($row['email']); ?>" class="box">
                    <span>Mettre à jour votre photo :</span>
                    <input type="file" name="update_image" accept="image/*" class="box">
                </div>
                <div class="inputBox">
                    <span>Ancien Mot de passe :</span>
                    <input type="password" name="old_pass" class="box">
                    <span>Nouveau Mot de passe :</span>
                    <input type="password" name="new_pass" class="box">
                    <span>Confirmer le Mot de passe :</span>
                    <input type="password" name="confirm_pass" class="box">
                </div>
            </div>
            <div class="flex btns">
                <input type="submit" value="Mettre à jour le profil" name="update_profile" class="btn">
                <a href="users.php" class="delete-btn">Retour</a>
            </div>
        </form>
    </div>

    <style>
      /* update profile */
      .update-profile {
          min-height:70vh;
          display: flex;
          align-items: center;
          justify-content: center;
          /* padding: 20px; */
          background-color: #f4f4f4; /* Couleur de fond pour le conteneur principal */
          /* position:fixed; */
          /* margin-left:24%; */
      }

      .update-profile form {
          padding: 15px;
          background: white; /* Couleur de fond du formulaire */
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Ombre du formulaire */
          text-align: center;
          width: 650px;
          border-radius: 5px;
          /*  */
      }

      .update-profile form img {
          height: 200px;
          width: 200px;
          border-radius: 50%; /* Pour faire une image circulaire */
          object-fit: cover; /* Pour couvrir l'image sans déformation */
          margin-bottom: 1px; /* Espace en bas de l'image */
      }

      .update-profile form .flex {
          display: flex;
          justify-content: space-between;
          margin-bottom: 20px;
          gap: 15px; /* Espacement entre les éléments */
      }

      .update-profile form .flex .inputBox {
          width: 45%; /* Largeur de chaque boîte d'entrée */
      }

      .update-profile form .flex .inputBox span {
          text-align: left;
          display: block;
          margin-top: 12px;
          font-size: 17px;
          color: #007bff; /* Couleur bleu pour le texte */
      }

      .update-profile form .flex .inputBox .box {
          width: 100%;
          border-radius: 5px;
          padding: 12px 3px;
          color: #007bff; /* Couleur du texte des boîtes */
          font-size: 18px;
          margin: 10px 0;
          background: #e9ecef; /* Couleur de fond légère pour les entrées */
          /* max-height:6px; */

      }

      /* Styles pour les boutons */
      .delete-btn {
          padding: 10px 95px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          color: white; /* Texte en blanc */
          font-size: 16px; /* Taille de police */
          text-align:center;
      }

      .btn {
          background-color: #28a745; /* Vert */
          border: none;
          border-radius: 5px;
          cursor: pointer;
          color: white; /* Texte en blanc */
          font-size: 16px; /* Taille de police */
          text-align:center;
          padding: 10px 45px;
      }

      .delete-btn {
          background-color: #dc3545; /* Rouge */
          /* margin-left: 10px; */
      }

      /* Styles des alertes */
      .alert {
          padding: 10px;
          margin-bottom: 15px;
          border-radius: 5px;
          background-color: #f8d7da; /* Couleur d'arrière-plan des alertes */
          color: #721c24; /* Couleur du texte des alertes */
          border: 1px solid #f5c6cb; /* Bordure des alertes */
      }

      @media (max-width: 650px){
          .update-profile {
              min-height: 50vh;
              padding: 0;
              height: 100%;
          }
          .update-profile form .flex {
              flex-wrap: wrap;
              gap: 0;
          }
          .update-profile form .flex .inputBox {
              width: 100%;
          }
      }
    </style>
</body>
</html>