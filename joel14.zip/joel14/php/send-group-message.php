<?php
session_start();
include_once "config.php"; // Assurez-vous que le chemin est correct

if (isset($_POST['group_id']) && isset($_POST['message'])) {
    $group_id = mysqli_real_escape_string($conn, $_POST['group_id']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $outgoing_id = $_SESSION['unique_id'];

    // Insertion du message dans la base de données
    $sql = "INSERT INTO messages (group_id, outgoing_msg_id, msg, date) VALUES ('$group_id', '$outgoing_id', '$message', NOW())";
    
    if (mysqli_query($conn, $sql)) {
        // Récupérer le nom de l'utilisateur pour l'affichage
        $user_sql = mysqli_query($conn, "SELECT fname, lname, img FROM users WHERE unique_id = '$outgoing_id'");
        
        if ($user_sql && mysqli_num_rows($user_sql) > 0) {
            $user = mysqli_fetch_assoc($user_sql);
            $sender_name = htmlspecialchars($user['fname'] . ' ' . $user['lname']);
            $sender_photo = 'php/images/' . htmlspecialchars($user['img']); // Chemin complet vers l'image
            $message_date = date('d/m/Y H:i', time());

            // Retourner le message formaté
            echo '<div class="message right">
                    
                    <strong>' . $sender_name . ':</strong> ' . htmlspecialchars($message) . '<br>
                    <small>' . $message_date . '</small>
                  </div>';
        } else {
            echo "Erreur lors de la récupération des informations de l'utilisateur.";
        }
    } else {
        echo "Erreur lors de l'envoi du message : " . mysqli_error($conn);
    }
} else {
    echo "Données manquantes.";
}
?>