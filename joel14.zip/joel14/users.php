<?php 
session_start();
include_once "php/config.php";

if (!isset($_SESSION['unique_id'])) {
    header("location: login.php");
    exit();
}

include_once "header.php"; 
?>
<body>
  <div class="wrappers">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if ($sql && mysqli_num_rows($sql) > 0) {
                $row = mysqli_fetch_assoc($sql);
            } else {
                echo "Utilisateur introuvable.";
                exit();
            }
          ?>
          <a href="update_profile.php?user_id=<?php echo htmlspecialchars($row['unique_id']); ?>">
            <img src="php/images/<?php echo htmlspecialchars($row['img']); ?>" alt="">
          </a>
          <div class="details">
            <span><?php echo htmlspecialchars($row['fname'] . " " . $row['lname']); ?></span>
            <p><?php echo htmlspecialchars($row['status']); ?></p>
          </div>
        </div>
        <a href="#" id="showCreateGroup" class="menu-icon"><i class="fas fa-plus"></i></a>
        <a href="php/logout.php?logout_id=<?php echo htmlspecialchars($row['unique_id']); ?>" class="logout">Logout</a>
      </header>

      <nav>
        <button id="showDiscussions">Discussions</button>
        <button id="showGroups">Groupes</button>
      </nav>

      <div class="search">
        <span class="text">Rechercher un utilisateur</span>
        <input type="text" placeholder="Entrez le nom à rechercher...">
        <button><i class="fas fa-search"></i></button>
      </div>

      <div class="users-list">
          <?php
            $sqlUsers = mysqli_query($conn, "SELECT * FROM users WHERE unique_id != {$_SESSION['unique_id']}");
            while ($user = mysqli_fetch_assoc($sqlUsers)) {
                echo '<div class="user-item" data-user-id="' . htmlspecialchars($user['unique_id']) . '">
                        <img src="php/images/' . htmlspecialchars($user['img']) . '" alt="">
                        <span>' . htmlspecialchars($user['fname'] . " " . $user['lname']) . '</span>
                      </div>';
            }
          ?>
        </div>

        <div id="menuContainer" style="display: none; position: fixed; top: 10px; left: 20px; z-index: 200;">
            <div class="menu-item" id="createGroup">
                <i class="fas fa-users"></i>
                <span>Nouveau groupe</span>
            </div>
            <div class="menu-item" id="addContact">
                <i class="fas fa-user-plus"></i>
                <span>Nouveau contact</span>
            </div>
            <div class="menu-item" id="createCommunity">
                <i class="fas fa-users"></i>
                <span>Nouvelle communauté</span>
            </div>
            <div class="menu-item" id="chatWithAI">
                <i class="fas fa-robot"></i>
                <span>Discutez avec des IA</span>
            </div>
            <button type="button" id="closeMenu">Fermer</button>
        </div>

      <div id="userList" style="display:none;">
        <h3>Sélectionnez des utilisateurs :</h3>
        <div class="users-list">
          <?php
            $sqlUsers = mysqli_query($conn, "SELECT * FROM users WHERE unique_id != {$_SESSION['unique_id']}");
            while ($user = mysqli_fetch_assoc($sqlUsers)) {
                echo '<div class="user-item" data-user-id="' . htmlspecialchars($user['unique_id']) . '">
                        <img src="php/images/' . htmlspecialchars($user['img']) . '" alt="">
                        <span>' . htmlspecialchars($user['fname'] . " " . $user['lname']) . '</span>
                      </div>';
            }
          ?>
        </div>
      </div>

      <div id="groupNameContainer" style="display: none;">
        <input type="text" id="groupName" placeholder="Nom du groupe" required>
        <button id="createGroupButton">Créer le groupe</button>
      </div>

      <div id="groupsContainer" style="display: none;">
        <h3>Mes Groupes</h3>
        <div id="groupsList"></div>
        <div id="noGroupsMessage" style="display: none;">Aucun groupe pour l'instant.</div>
      </div>
    </section>

    <button id="continueSelection" style="display: none;">Suivant</button> 
  </div>

  <script src="javascript/users.js"></script>
  <script>
      document.getElementById('showCreateGroup').onclick = function() {
        document.getElementById('menuContainer').style.display = 'block';
    };

    document.getElementById('closeMenu').onclick = function() {
        document.getElementById('menuContainer').style.display = 'none';
    };

    document.getElementById('createGroup').onclick = function() {
        document.getElementById('menuContainer').style.display = 'none'; // Masquer le menu
        document.getElementById('userList').style.display = 'block'; // Afficher la section de sélection des utilisateurs
        document.querySelector('.users-list').style.display = 'none'; // Masquer la liste des utilisateurs
        document.getElementById('groupsContainer').style.display = 'none'; // Masquer la section des groupes
    };

    document.querySelectorAll('.user-item').forEach(item => {
        item.onclick = function() {
            item.classList.toggle('selected');
            document.getElementById('continueSelection').style.display = 'block';
        };
    });

    document.getElementById('continueSelection').onclick = function() {
        const selectedUsers = document.querySelectorAll('.user-item.selected');
        if (selectedUsers.length > 0) {
            document.getElementById('userList').style.display = 'none';
            document.getElementById('groupNameContainer').style.display = 'block';
        } else {
            alert("Veuillez sélectionner au moins un utilisateur.");
        }
    };

    document.getElementById('createGroupButton').onclick = function() {
        const groupName = document.getElementById('groupName').value;
        const selectedUsers = Array.from(document.querySelectorAll('.user-item.selected')).map(item => item.getAttribute('data-user-id'));

        if (groupName && selectedUsers.length > 0) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "php/create-groupe.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onload = () => {
                if (xhr.status === 200) {
                    alert(xhr.response);
                    document.getElementById('groupName').value = '';
                    document.getElementById('menuContainer').style.display = 'none';
                    loadGroups(); // Recharge les groupes après la création
                } else {
                    alert("Erreur lors de la création du groupe. Veuillez réessayer.");
                }
            };
            xhr.onerror = () => {
                alert("Erreur de connexion. Veuillez vérifier votre connexion internet.");
            };
            xhr.send("group_name=" + encodeURIComponent(groupName) + "&users=" + encodeURIComponent(JSON.stringify(selectedUsers)));
        } else {
            alert("Veuillez entrer un nom de groupe et sélectionner des utilisateurs.");
        }
    };

    document.getElementById('showDiscussions').onclick = function() {
        document.getElementById('groupsContainer').style.display = 'none'; // Masquer les groupes
        document.getElementById('userList').style.display = 'none'; // Masquer la section de sélection des utilisateurs
        document.querySelector('.users-list').style.display = 'block'; // Afficher la liste des utilisateurs
    };

    document.getElementById('showGroups').onclick = function() {
        document.getElementById('userList').style.display = 'none'; // Masquer la section de sélection des utilisateurs
        document.querySelector('.users-list').style.display = 'none'; // Masquer la liste des utilisateurs
        document.getElementById('groupsContainer').style.display = 'block'; // Afficher le conteneur des groupes
        loadGroups(); // Charger les groupes
    };

    function loadGroups() {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "php/load-group.php", true);
        xhr.onload = () => {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.response);
                const groupsList = document.getElementById('groupsList');
                groupsList.innerHTML = '';

                if (response.error) {
                    alert(response.error);
                } else if (response.message) {
                    alert(response.message); // Affiche le message d'absence de groupes
                    document.getElementById('noGroupsMessage').innerText = response.message;
                    document.getElementById('noGroupsMessage').style.display = 'block';
                } else if (response.length > 0) {
                    response.forEach(group => {
                        const avatar = group.avatar ? group.avatar : 'php/images/default-avatar.png'; // Avatar par défaut
                        groupsList.innerHTML += `
                            <div class="group-item" data-group-id="${group.group_id}">
                                <img src="${avatar}" alt="Avatar du groupe" class="group-avatar">
                                <span>${group.nom_groupe}</span>
                            </div>`;
                    });
                    document.getElementById('noGroupsMessage').style.display = 'none';
                }
                document.getElementById('groupsContainer').style.display = 'block'; // Afficher le conteneur des groupes
            } else {
                alert("Erreur de réponse du serveur. Statut : " + xhr.status);
            }
        };
        xhr.onerror = () => {
            alert("Erreur de connexion. Veuillez vérifier votre connexion internet.");
        };
        xhr.send();
    }

    // Gestion des clics sur les groupes
    document.getElementById('groupsList').onclick = function(event) {
        const groupItem = event.target.closest('.group-item');
        if (groupItem) {
            const groupId = groupItem.getAttribute('data-group-id');
            window.location.href = 'discussion.php?group_id=' + groupId; // Redirection vers la page de discussion
        }
    };
  </script>

  <style>
    .menu-icon {
        display: inline-flex;
        justify-content: center;
        align-items: center;
        width: 50px;
        height: 50px;
        background-color: #4CAF50;
        border-radius: 15px;
        color: white;
        text-decoration: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: 0.3s;
    }

    .menu-icon:hover {
        background-color: #45a049;
    }

    #menuContainer {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        padding: 10px;
        position: fixed;
        top: 10px;
        left: 20px;
        z-index: 200;
    }

    .user-item {
        display: flex;
        align-items: center;
        padding: 10px;
        cursor: pointer;
    }

    .user-item.selected {
        background-color: #d1ffd1;
        margin-top: 5px;
    }

    .user-item img {
        width: 40px;
        height: 40px;
        border-radius: 20px;
        margin-right: 10px;
    }

    .group-item {
        display: flex;
        align-items: center;
        padding: 10px;
        cursor: pointer;
    }

    .group-item img {
        width: 40px;
        height: 40px;
        border-radius: 20px;
        margin-right: 10px;
    }

    #groupNameContainer {
        margin-top: 20px;
    }
    
    .menu-item i {
        display: inline-flex;
        justify-content: center;
        align-items: center;
        width: 50px;
        height: 50px;
        background-color: #4CAF50;
        border-radius: 15px;
        color: white;
        text-decoration: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: 0.3s;
        cursor: pointer;
    }
    
    #continueSelection {
        margin-bottom: 227px;
    }

    nav {
        margin: 15px 0;
    }

    nav button {
        margin-right: 10px;
        padding: 10px 15px;
        cursor: pointer;
    }
  </style>
</body>
</html>