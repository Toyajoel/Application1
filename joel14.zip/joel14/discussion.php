<?php 
session_start();
include_once "php/config.php";
if (!isset($_SESSION['unique_id'])) {
    header("location: login.php");
}
?>
<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="chat-area">
      <header>
      <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
        <?php 
          if (isset($_GET['group_id']) && is_numeric($_GET['group_id'])) {
              $group_id = mysqli_real_escape_string($conn, $_GET['group_id']);
              
              // Requête pour récupérer les informations du groupe
              $query = "SELECT * FROM groupes WHERE group_id = {$group_id}";
              $sql = mysqli_query($conn, $query);
              
              // Vérifiez si la requête a réussi
              if (!$sql) {
                  die("Erreur dans la requête : " . mysqli_error($conn));
              }

              if (mysqli_num_rows($sql) > 0) {
                  $row = mysqli_fetch_assoc($sql);
                  if (isset($row['nom_groupe']) && isset($row['avatar'])) {
                      // Afficher le nom du groupe et l'avatar
                      echo '<img src="' . htmlspecialchars($row['avatar']) . '" alt="Avatar du groupe" style="width: 50px; height: 50px;">';
                      echo '<span>' . htmlspecialchars($row['nom_groupe']) . '</span>';
                  } else {
                      echo "Le champ 'nom_groupe' ou 'avatar' est manquant.";
                  }
              } else {
                  echo "Aucun groupe trouvé avec l'ID : {$group_id}.";
              }
          } else {
              die("ID de groupe non valide.");
          }
        ?>
        
        <div class="discussion-title">
          <h4 >Discussion de groupe  </h4>
        </div>
      </header>
      <div class="chat-box" id="messageList">
        <!-- Les messages apparaîtront ici -->
      </div>
      <form id="messageForm" class="typing-area" enctype="multipart/form-data">
        <input type="hidden" name="group_id" value="<?php echo $group_id; ?>">
        
        <button type="button" class="file-btn" id="fileButton"><i class="fas fa-paperclip"></i></button>
        <div class="file-options" style="display: none;">
            <button type="button" id="documentButton">Document</button>
            <button type="button" id="photoButton">Photo</button>
            <input type="file" id="fileInput" name="message" style="display: none;" />
        </div>
        
        <input type="text" name="message" class="input-field" id="messageInput" placeholder="Taper un message ici..." autocomplete="off">
        <button type="submit"><i class="fab fa-telegram-plane"></i></button>
        <button type="button" id="voiceButton"><i class="fas fa-microphone"></i></button>
      </form>
    </section>
  </div>

  <script src="javascript/group-chat.js"></script> <!-- Fichier JS pour la logique de groupe -->
  
  <script>
    // Récupérer les messages au chargement de la page
    window.onload = function() {
      loadMessages();
    };
    
    // Fonction pour charger les messages
    function loadMessages() {
      groupId = document.querySelector('input[name="group_id"]').value;

      fetch('php/get-group-chat.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'group_id=' + groupId
      })
      .then(response => response.text())
      .then(data => {
        document.getElementById('messageList').innerHTML = data;
      });
    }

    const form = document.getElementById("messageForm");
    const messageInput = document.getElementById("messageInput");

    form.onsubmit = function(e) {
        e.preventDefault(); // Empêche le rechargement de la page
        sendMessage(); // Appelle la fonction d'envoi
    };

    function sendMessage() {
        const formData = new FormData(form);
        
        fetch('php/send-groupe-message.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            messageInput.value = ''; // Efface le champ de message
            loadMessages(); // Recharge les messages
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    }
  </script>
 <style>
    .discussion-title {
        margin-bottom: 25px; 
        color: white;
        margin-left: 59px;
        font-style: italic;
    }

    .message {
        display: flex;
        align-items: center;
        margin: 10px 0;
    }

    .message.right {
        justify-content: flex-end;
    }

    .message.left {
        justify-content: flex-start;
    }

    .user-photo {
        width: 30px; /* Ajustez la taille de la photo */
        height: 30px; /* Ajustez la taille de la photo */
        border-radius: 50%; /* Pour un effet circulaire */
        margin-right: 8px; /* Espace entre l'image et le texte */
    }

    /* Styles génériques pour les messages */
    .details {
        max-width: 75%; /* Limite la largeur des messages */
        padding: 10px; /* Espacement intérieur */
        color: #fff; /* Couleur du texte */
    }

    .outgoing .details p {
        background: #079f4e; /* Couleur d'arrière-plan pour les messages sortants */
        border-radius: 18px 18px 0 18px; /* Arrondi des coins */
    }

    .incoming .details p {
        background: #333; /* Couleur d'arrière-plan pour les messages entrants */
        border-radius: 18px 18px 18px 0; /* Arrondi des coins */
    }
    .timestamp {
    font-size: 0.8em; /* Réduit la taille de la police */
    margin-left: 25px; /* Ajoute un espace entre le message et la date */
    /* color: #888; Change la couleur pour un effet plus subtil */
    /* display: inline-block; Assure que cela ne prenne que l'espace nécessaire */
    padding-bottom: 55px;
    color:black;
}

    /* Styles spécifiques pour les messages entrants */
    .incoming img {
        border-radius: 50%; /* Arrondit l'image de profil */
        width: 40px; /* Largeur de l'image */
        height: 40px; /* Hauteur de l'image */
        margin-right: 10px; /* Espace entre l'image et le message */
    }

    /* .new-message-indicator {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: yellow;
    padding: 10px;
    border-radius: 5px;
    z-index: 1000;
} */
.chat-box {
    /* height: 400px; Ajustez selon vos besoins */
    overflow-y: auto; /* Permet le défilement vertical */
}
</style>
</body>
</html>