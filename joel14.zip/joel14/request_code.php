<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

$host = "localhost";
$dbname = "chatapp"; // Remplace par le nom de ta base
$username = "root"; // Remplace par ton utilisateur MySQL
$password = ""; // Remplace par ton mot de passe MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Gérer l'envoi du code de réinitialisation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'])) {
    $email = $_POST['email'];

    // Vérifier si l'email a un format valide
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Veuillez entrer une adresse e-mail valide.'); window.location.href = 'request_code.php';</script>";
        exit();
    }

    // Vérifier si l'email existe dans la base de données
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        // Stocker l'email dans la session
        $_SESSION['reset_email'] = $email;

        // Générer un code à 6 chiffres
        $reset_code = mt_rand(100000, 999999);

        // Enregistrer le code dans la base de données
        $stmt = $pdo->prepare("UPDATE users SET reset_code = ?, code_expiry = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE email = ?");
        $stmt->execute([$reset_code, $email]);

        // Configurer PHPMailer
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Remplace par ton serveur SMTP
            $mail->SMTPAuth = true;
            $mail->Username = 'toyatankwajoelsorel@gmail.com'; // Remplace par ton email
            $mail->Password = 'kkeo hkfq uwvr bzsn'; // Remplace par ton mot de passe SMTP
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Destinataire et contenu de l'email
            $mail->setFrom('toyatankwajoelsorel@gmail.com', 'Support');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Réinitialisation de votre mot de passe';
            $mail->Body = "<p>Bonjour,</p>
                           <p>Voici votre code de réinitialisation : <strong>$reset_code</strong></p>
                           <p>Ce code est valable pendant 30 minutes.</p>
                           <p>Si vous n'avez pas demandé cette réinitialisation, ignorez cet e-mail.</p>";

            $mail->send();
            echo "<script>alert('Un code de réinitialisation a été envoyé à votre adresse e-mail.'); window.location.href = 'verify_code.php';</script>";
        } catch (Exception $e) {
            echo "Erreur lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
        }
    } else {
        echo "<script>alert('Cet e-mail n\'existe pas dans notre base de données.'); window.location.href = 'request_code.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demande de Réinitialisation</title>
    <style>
        /* Ajouter votre style ici */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            margin-bottom: 20px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <h1>Réinitialisation du mot de passe</h1>
            <input type="email" name="email" placeholder="Entrez votre email" required>
            <button type="submit">Envoyer le code</button>
        </form>
    </div>
</body>
</html>