<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$dbname = "chatapp"; // Remplace par le nom de ta base
$username = "root"; // Remplace par ton utilisateur MySQL
$password = ""; // Remplace par ton mot de passe MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Gérer la réinitialisation du mot de passe
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['new_password'])) {
    // Hachage du mot de passe avec md5
    $new_password = md5($_POST['new_password']); // Hachage avec md5

    // Mettre à jour le mot de passe dans la base de données
    $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_code = NULL, code_expiry = NULL WHERE email = ?");
    if ($stmt->execute([$new_password, $_SESSION['reset_email']])) {
        // Message de succès et redirection vers la page de connexion
        echo "<script>alert('Votre mot de passe a été réinitialisé avec succès.'); window.location.href = 'login.php';</script>";
        session_destroy();
        exit();
    } else {
        echo "<script>alert('Échec de la mise à jour du mot de passe.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation du Mot de Passe</title>
    <style>
        /* Ajouter votre style ici */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            margin-bottom: 20px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <h1>Réinitialisation du Mot de Passe</h1>
            <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
            <button type="submit">Réinitialiser le mot de passe</button>
        </form>
    </div>
</body>
</html>