const form = document.querySelector(".typing-area");
const group_id = form.querySelector("input[name='group_id']").value;
const inputField = form.querySelector(".input-field");
const sendBtn = form.querySelector("button[type='submit']");
const chatBox = document.querySelector(".chat-box");

form.onsubmit = (e) => {
    e.preventDefault(); // Empêche le rechargement de la page
};

inputField.focus();
inputField.onkeyup = () => {
    sendBtn.classList.toggle("active", inputField.value.trim() !== "");
};

let isSending = false;

sendBtn.onclick = () => {
    if (inputField.value.trim() === "") {
        alert("Le message ne peut pas être vide.");
        return;
    }
    
    if (!isSending) {
        isSending = true;
        sendMessage();
    }
};

function sendMessage() {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "php/send-group-message.php", true);
    xhr.onload = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                console.log("Réponse du serveur :", xhr.response);
                chatBox.innerHTML += xhr.response; // Ajouter le message à la chat box
                inputField.value = '';
                inputField.focus();
                sendBtn.classList.remove("active");

                // Vérifiez si l'utilisateur est en bas avant de défiler
                const isScrolledToBottom = chatBox.scrollHeight - chatBox.clientHeight <= chatBox.scrollTop + 1;
                if (isScrolledToBottom) {
                    scrollToBottom();
                }
            } else {
                console.error("Erreur lors de l'envoi du message : " + xhr.statusText);
                alert("Une erreur est survenue lors de l'envoi du message. Veuillez réessayer.");
            }
            isSending = false;
        }
    };

    let formData = new FormData(form);
    xhr.send(formData);
}

setInterval(() => {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "php/get-group-chat.php", true);
    xhr.onload = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                const previousScrollHeight = chatBox.scrollHeight; // Enregistrez la hauteur précédente
                chatBox.innerHTML = xhr.response; // Mettre à jour le contenu des messages

                // Vérifiez si l'utilisateur est en bas
                const isScrolledToBottom = chatBox.scrollHeight - chatBox.clientHeight <= chatBox.scrollTop + 1;

                // Si l'utilisateur est en bas, faites défiler vers le bas
                if (isScrolledToBottom) {
                    scrollToBottom();
                }
            } else {
                console.error("Erreur lors de la récupération des messages : " + xhr.statusText);
            }
        }
    };
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("group_id=" + group_id);
}, 500);

function scrollToBottom() {
    chatBox.scrollTop = chatBox.scrollHeight;
}


// let newMessageIndicator = document.createElement('div');
// newMessageIndicator.className = 'new-message-indicator';
// newMessageIndicator.style.display = 'none'; // Masqué par défaut
// newMessageIndicator.innerText = 'Nouveaux messages';
// document.body.appendChild(newMessageIndicator);

// // Vérifiez si l'utilisateur est en bas
// if (!isScrolledToBottom) {
//     newMessageIndicator.style.display = 'block'; // Affichez l'indicateur
// } else {
//     newMessageIndicator.style.display = 'none'; // Masquez l'indicateur
// }

// Emoji Picker Logic
$(document).ready(function () {
    $('.input-field').emojioneArea({
        pickerPosition: "top",
        toneStyle: "bullet"
    });

    $('#emojiButton').click(function () {
        // Vérifiez si le sélecteur d'emojis est déjà ouvert
        if ($('.emoji-picker').length > 0) {
            $('.emoji-picker').remove(); // Fermer le sélecteur existant
            return;
        }

        const emojiPicker = document.createElement('div');
        emojiPicker.classList.add('emoji-picker');
        emojiPicker.style.position = 'absolute';
        emojiPicker.style.zIndex = '1000';
        emojiPicker.style.backgroundColor = '#796263'; // Couleur de fond
        emojiPicker.style.border = '1px solid #ccc'; // Bordure
        emojiPicker.style.borderRadius = '5px'; // Arrondir les coins
        emojiPicker.style.padding = '10px'; // Espacement

        // Créer le sélecteur d'emojis
        for (let i = 128512; i <= 128591; i++) {
            const emoji = String.fromCodePoint(i);
            const emojiSpan = document.createElement('span');
            emojiSpan.innerText = emoji;
            emojiSpan.style.cursor = 'pointer';
            emojiSpan.style.fontSize = '24px';
            emojiSpan.style.margin = '5px'; // Marge entre les emojis
            emojiSpan.onclick = function () {
                const inputField = $('.input-field');
                inputField.data("emojioneArea").setText(inputField.data("emojioneArea").getText() + emoji); // Ajouter l'emoji au champ de texte
                $('.emoji-picker').remove(); // Fermer le sélecteur après sélection
                inputField.focus(); // Remettre le focus sur le champ de texte
            };
            emojiPicker.appendChild(emojiSpan);
        }

        document.body.appendChild(emojiPicker);
        
        // Positionner le sélecteur d'emojis juste au-dessus du bouton
        const buttonRect = $('#emojiButton')[0].getBoundingClientRect();
        emojiPicker.style.left = `${buttonRect.left}px`;
        emojiPicker.style.top = `${buttonRect.top - emojiPicker.offsetHeight}px`; // Positionner juste au-dessus
    });
});
