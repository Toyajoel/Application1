const form = document.querySelector(".typing-area"),
    incoming_id = form.querySelector(".incoming_id").value,
    inputField = form.querySelector(".input-field"),
    sendBtn = form.querySelector("button[type='submit']"),
    chatBox = document.querySelector(".chat-box");

// Empêche le comportement par défaut du formulaire
form.onsubmit = (e) => {
    e.preventDefault();
};

inputField.focus();
inputField.onkeyup = () => {
    if (inputField.value != "") {
        sendBtn.classList.add("active");
    } else {
        sendBtn.classList.remove("active");
    }
};

// Variable pour éviter les envois multiples
let isSending = false;

sendBtn.onclick = () => {
    if (!isSending) {
        isSending = true;
        sendMessage();
    }
};

function sendMessage() {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "php/insert-chat.php", true);
    xhr.onload = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Effacer le champ de texte et le champ de fichier après l'envoi
                inputField.value = ''; // Effacer le champ texte
                document.getElementById('fileInput').value = ''; // Effacer le champ fichier
                inputField.focus(); // Remettre le focus sur le champ de texte
                scrollToBottom(); // Scroller vers le bas pour voir le dernier message
                sendBtn.classList.remove("active"); // Désactiver le bouton d'envoi
            }
            isSending = false; // Réinitialiser l'état d'envoi
        }
    };

    let formData = new FormData(form); // Récupérer les données du formulaire
    xhr.send(formData); // Envoyer les données
}

chatBox.onmouseenter = () => {
    chatBox.classList.add("active");
};

chatBox.onmouseleave = () => {
    chatBox.classList.remove("active");
};

// Pour la mise à jour des messages
setInterval(() => {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "php/get-chat.php", true);
    xhr.onload = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                let data = xhr.response;
                chatBox.innerHTML = data;
                if (!chatBox.classList.contains("active")) {
                    scrollToBottom();
                }
            }
        }
    };
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("incoming_id=" + incoming_id);
}, 500);

function scrollToBottom() {
    chatBox.scrollTop = chatBox.scrollHeight; // Faire défiler la boîte de chat vers le bas
}

// Emoji Picker Logic
$(document).ready(function () {
    $('.input-field').emojioneArea({
        pickerPosition: "top",
        toneStyle: "bullet"
    });

    $('#emojiButton').click(function () {
        // Vérifiez si le sélecteur d'emojis est déjà ouvert
        if ($('.emoji-picker').length > 0) {
            $('.emoji-picker').remove(); // Fermer le sélecteur existant
            return;
        }

        const emojiPicker = document.createElement('div');
        emojiPicker.classList.add('emoji-picker');
        emojiPicker.style.position = 'absolute';
        emojiPicker.style.zIndex = '1000';
        emojiPicker.style.backgroundColor = '#796263'; // Couleur de fond
        emojiPicker.style.border = '1px solid #ccc'; // Bordure
        emojiPicker.style.borderRadius = '5px'; // Arrondir les coins
        emojiPicker.style.padding = '10px'; // Espacement

        // Créer le sélecteur d'emojis
        for (let i = 128512; i <= 128591; i++) {
            const emoji = String.fromCodePoint(i);
            const emojiSpan = document.createElement('span');
            emojiSpan.innerText = emoji;
            emojiSpan.style.cursor = 'pointer';
            emojiSpan.style.fontSize = '24px';
            emojiSpan.style.margin = '5px'; // Marge entre les emojis
            emojiSpan.onclick = function () {
                const inputField = $('.input-field');
                inputField.data("emojioneArea").setText(inputField.data("emojioneArea").getText() + emoji); // Ajouter l'emoji au champ de texte
                $('.emoji-picker').remove(); // Fermer le sélecteur après sélection
                inputField.focus(); // Remettre le focus sur le champ de texte
            };
            emojiPicker.appendChild(emojiSpan);
        }

        document.body.appendChild(emojiPicker);
        
        // Positionner le sélecteur d'emojis juste au-dessus du bouton
        const buttonRect = $('#emojiButton')[0].getBoundingClientRect();
        emojiPicker.style.left = `${buttonRect.left}px`;
        emojiPicker.style.top = `${buttonRect.top - emojiPicker.offsetHeight}px`; // Positionner juste au-dessus
    });
});


