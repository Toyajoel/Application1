<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$dbname = "chatapp"; // Remplace par le nom de ta base
$username = "root"; // Remplace par ton utilisateur MySQL
$password = ""; // Remplace par ton mot de passe MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Gérer la vérification du code
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['code'])) {
    $code = $_POST['code'];

    // Vérifier le code et son expiration
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND reset_code = ? AND code_expiry > NOW()");
    $stmt->execute([$_SESSION['reset_email'], $code]);
    $user = $stmt->fetch();

    if ($user) {
        // Code valide, afficher le formulaire de réinitialisation
        $_SESSION['code_verified'] = true;
        header("Location: reset_password.php");
        exit();
    } else {
        echo "<script>alert('Le code est invalide ou a expiré.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification du Code</title>
    <style>
        /* Style de base pour le formulaire */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            margin-bottom: 20px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <h1>Vérification du Code</h1>
            <input type="text" name="code" placeholder="Entrez le code reçu" required>
            <button type="submit">Vérifier</button>
        </form>
    </div>
</body>
</html>