<?php
session_start();
include_once "config.php";

if (isset($_POST['group_id'])) {
    $group_id = mysqli_real_escape_string($conn, $_POST['group_id']);

    // Requête pour récupérer les messages de la table 'messages'
    $sql = "SELECT * FROM messages WHERE group_id = '$group_id' ORDER BY date ASC";
    $result = mysqli_query($conn, $sql);

    // Vérification de la réussite de la requête
    if (!$result) {
        die("Erreur dans la requête : " . mysqli_error($conn));
    }

    // Vérification des messages
    if (mysqli_num_rows($result) == 0) {
        echo '<div class="message">Aucun message dans ce groupe.</div>';
    } else {
        // Afficher chaque message
        while ($message = mysqli_fetch_assoc($result)) {
            $sender_id = $message['outgoing_msg_id'];
            $user_sql = mysqli_query($conn, "SELECT fname, lname, img FROM users WHERE unique_id = '$sender_id'");
            if (!$user_sql) {
                die("Erreur dans la requête utilisateur : " . mysqli_error($conn));
            }
            $user = mysqli_fetch_assoc($user_sql);
            if ($user) {
                $sender_name = htmlspecialchars($user['fname'] . ' ' . $user['lname']);
                $sender_photo =  'php/images/'.htmlspecialchars($user['img']); // Récupération de la photo
            } else {
                $sender_name = "Utilisateur inconnu";
                $sender_photo = "default-avatar.png"; // Photo par défaut si non trouvé
            }
            $message_date = date('H:i', strtotime($message['date']));
            $formatted_date = date('d/m/Y', strtotime($message['date']));

            // Vérifiez si c'est votre message ou celui d'un autre membre
            $is_outgoing = ($sender_id === $_SESSION['unique_id']);
            $message_class = $is_outgoing ? 'outgoing' : 'incoming';

            // Structurer l'affichage du message
            echo '<div class="chat ' . $message_class . '">';
            if (!$is_outgoing) {
                echo '<img src="' . $sender_photo . '" alt="Photo de ' . $sender_name . '" class="user-photo">';
                echo '<strong>' . $sender_name . ':</strong>'; // Nom de l'utilisateur au-dessus du message
            }
            echo '<div class="details">';
           
            echo '<p>' . htmlspecialchars($message['msg']) . '
            <span></span><br>
            <span class="timestamp">' . $message_date . '</span>
            </p>'; // Message
            echo '<small class="timestamp">' . $formatted_date . '</small>'; // Date et heure
            echo '</div>'; // Ferme details
            echo '</div>'; // Ferme chat
        }
    }
}
?>