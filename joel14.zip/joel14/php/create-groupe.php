<?php
session_start();
include_once "config.php";

if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["error" => "Utilisateur non connecté."]);
    exit();
}

$user_id = $_SESSION['unique_id'];
$nom_groupe = mysqli_real_escape_string($conn, $_POST['group_name']);
$users = json_decode($_POST['users']); // Récupérer les utilisateurs sélectionnés

if (empty($nom_groupe)) {
    echo json_encode(["error" => "Le nom du groupe ne peut pas être vide."]);
    exit();
}

// 1. Insérer le groupe dans la table `groupes`
$sql = "INSERT INTO `groupes` (nom_groupe, creer_par) VALUES ('$nom_groupe', $user_id)";

if (mysqli_query($conn, $sql)) {
    // 2. Récupérer l'ID du groupe nouvellement créé
    $group_id = mysqli_insert_id($conn);
    
    // 3. Insérer les utilisateurs dans la table `group_users`
    foreach ($users as $user) {
        $sql_user = "INSERT INTO `group_users` (group_id, user_id) VALUES ($group_id, $user)";
        if (!mysqli_query($conn, $sql_user)) {
            echo json_encode(["error" => "Erreur lors de l'ajout de l'utilisateur au groupe : " . mysqli_error($conn)]);
            exit();
        }
    }
    
    echo json_encode(["success" => "Groupe créé avec succès."]);
} else {
    echo json_encode(["error" => "Erreur lors de la création du groupe : " . mysqli_error($conn) . " - Requête : " . $sql]);
}
?>