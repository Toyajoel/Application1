<?php
while ($row = mysqli_fetch_assoc($query)) {
    // Vérifier le nombre de messages non lus pour cet utilisateur
    $sqlUnreadCount = "SELECT COUNT(*) as unread_count FROM messages 
                       WHERE incoming_msg_id = {$row['unique_id']} 
                       AND outgoing_msg_id = {$outgoing_id} 
                       AND read_status = 0"; // Messages non lus pour l'utilisateur
    $unreadCountQuery = mysqli_query($conn, $sqlUnreadCount);

    if (!$unreadCountQuery) {
        die("Erreur lors du comptage des messages non lus: " . mysqli_error($conn));
    }

    $unreadCountRow = mysqli_fetch_assoc($unreadCountQuery);
    $unreadCount = $unreadCountRow ? $unreadCountRow['unread_count'] : 1;

    // Récupérer le dernier message
    $sql2 = "SELECT msg, outgoing_msg_id FROM messages WHERE (incoming_msg_id = {$row['unique_id']}
            AND outgoing_msg_id = {$outgoing_id}) OR (incoming_msg_id = {$outgoing_id} 
            AND outgoing_msg_id = {$row['unique_id']}) ORDER BY msg_id DESC LIMIT 1";
    $query2 = mysqli_query($conn, $sql2);

    if (!$query2) {
        die("Erreur lors de la récupération du dernier message: " . mysqli_error($conn));
    }

    $row2 = mysqli_fetch_assoc($query2);
    $result = (mysqli_num_rows($query2) > 0) ? $row2['msg'] : "Aucun message disponible";
    $msg = (strlen($result) > 28) ? substr($result, 0, 28) . '...' : $result;

    // Déterminer si le dernier message vient de vous
    $you = (isset($row2['outgoing_msg_id']) && $outgoing_id == $row2['outgoing_msg_id']) ? "vous: " : "";

    // Vérifier le statut de l'utilisateur
    $offline = ($row['status'] == "Hors ligne") ? "offline" : "";
    $hid_me = ($outgoing_id == $row['unique_id']) ? "hide" : "";

    // Afficher le badge de messages non lus
    $unreadBadge = $unreadCount > 0 ? "<span class='badge'>{$unreadCount}</span>" : "";

    // Générer l'affichage de l'utilisateur
    $output .= '<a href="chat.php?user_id=' . $row['unique_id'] . '">
                <div class="content">
                    <img src="php/images/' . htmlspecialchars($row['img']) . '" alt="">
                    <div class="details">
                        <span>' . htmlspecialchars($row['fname'] . " " . $row['lname']) . '</span>
                        <p>' . $you . htmlspecialchars($msg) . '</p>
                    </div>
                    ' . $unreadBadge . ' <!-- Affichage du badge -->
                </div>
                <div class="status-dot ' . $offline . '"><i class="fas fa-circle"></i></div>
            </a>';
}
?>