

<?php 

session_start();
if (isset($_SESSION['unique_id'])) {
    include_once "config.php";
    $outgoing_id = $_SESSION['unique_id'];
    $incoming_id = mysqli_real_escape_string($conn, $_POST['incoming_id']);
    $output = "";
    
    $sql = "SELECT * FROM messages LEFT JOIN users ON users.unique_id = messages.outgoing_msg_id
            WHERE (outgoing_msg_id = {$outgoing_id} AND incoming_msg_id = {$incoming_id})
            OR (outgoing_msg_id = {$incoming_id} AND incoming_msg_id = {$outgoing_id}) ORDER BY msg_id";
    $query = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($query) > 0) {
        while ($row = mysqli_fetch_assoc($query)) {
            // Vérifier si la date est valide
            if ($row['date'] && strtotime($row['date']) !== false) {
                $formatted_date = date(" H:i:s", strtotime($row['date']));
                $formatted1_date = date("d/m/Y ", strtotime($row['date']));
            } else {
                $formatted_date = "Date non valide"; // Message par défaut si la date est invalide
            }
            
            if ($row['outgoing_msg_id'] === $outgoing_id) {
                $output .= '<div class="chat outgoing">
                            <div class="details">
                                <p>' . $row['msg'] . '
                                 <span></span><br>
                                 <span class="timestamp">' . $formatted_date . '</span>
                                </p>
                                <span class="timestamp">' . $formatted1_date . '</span>
                               
                            </div>
                            </div>';
            } else {
                $output .= '<div class="chat incoming">
                            <img src="php/images/' . $row['img'] . '" alt="">
                            <div class="details">
                                <p>' . $row['msg'] . '
                                
                                 <span class="timestamp">' . $formatted_date . '</span>
                                
                                </p>
                                  <span class="timestamp">' . $formatted1_date . '</span>
                                
                            </div>
                            </div>';
            }
        }
    } else {
        $output .= '<div class="text">Aucun message n\'est disponible. Une fois que vous avez envoyé un message, il apparaîtra ici.</div>';
    }
    echo $output;
} else {
    header("location: ../login.php");
}


?>
<style>
.timestamp {
    font-size: 0.8em; /* Réduit la taille de la police */
    margin-left: 25px; /* Ajoute un espace entre le message et la date */
    /* color: #888; Change la couleur pour un effet plus subtil */
    /* display: inline-block; Assure que cela ne prenne que l'espace nécessaire */
    padding-bottom: 55px;
}
</style>