-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 21 mars 2025 à 14:59
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `chatapp`
--

-- --------------------------------------------------------

--
-- Structure de la table `groupes`
--

DROP TABLE IF EXISTS `groupes`;
CREATE TABLE IF NOT EXISTS `groupes` (
  `group_id` int NOT NULL AUTO_INCREMENT,
  `nom_groupe` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `creer_par` int DEFAULT NULL,
  `creer_à` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `avatar` varchar(255) COLLATE utf8mb4_bin DEFAULT 'php/images/default-avatar.png',
  PRIMARY KEY (`group_id`),
  KEY `creer_par` (`creer_par`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Déchargement des données de la table `groupes`
--

INSERT INTO `groupes` (`group_id`, `nom_groupe`, `creer_par`, `creer_à`, `avatar`) VALUES
(1, 'gestion ', 1441627178, '2025-03-16 01:47:20', 'php/images/default-avatar.png'),
(2, 'igl2bj', 511427538, '2025-03-16 02:44:48', 'php/images/default-avatar.png'),
(3, 'maths', 511427538, '2025-03-16 03:12:49', 'php/images/default-avatar.png'),
(4, 'TLC', 1441627178, '2025-03-16 03:13:52', 'php/images/default-avatar.png'),
(5, 'licence', 511427538, '2025-03-16 03:21:26', 'php/images/default-avatar.png'),
(6, 'mes amis', 1441627178, '2025-03-16 03:39:41', 'php/images/default-avatar.png'),
(7, 'rs', 1441627178, '2025-03-17 06:58:21', 'php/images/default-avatar.png'),
(8, 'famille', 1441627178, '2025-03-17 12:43:54', 'php/images/default-avatar.png'),
(9, 'TLC & D', 1189816813, '2025-03-17 14:09:26', 'php/images/default-avatar.png'),
(10, 'gl', 1441627178, '2025-03-19 14:50:44', 'php/images/default-avatar.png'),
(11, 'bts', 1014598516, '2025-03-19 15:48:49', 'php/images/default-avatar.png');

-- --------------------------------------------------------

--
-- Structure de la table `group_users`
--

DROP TABLE IF EXISTS `group_users`;
CREATE TABLE IF NOT EXISTS `group_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Déchargement des données de la table `group_users`
--

INSERT INTO `group_users` (`id`, `group_id`, `user_id`) VALUES
(1, 1, 1461853210),
(2, 1, 1335120154),
(3, 2, 1441627178),
(4, 3, 1441627178),
(5, 4, 511427538),
(6, 5, 1441627178),
(7, 6, 1332942912),
(8, 6, 1101274758),
(9, 6, 446100033),
(10, 7, 1332942912),
(11, 7, 446100033),
(12, 8, 1189816813),
(13, 9, 1441627178),
(14, 10, 1601527834),
(15, 10, 1332942912),
(16, 11, 1601527834),
(17, 11, 1441627178),
(18, 11, 552497728),
(19, 11, 1101274758);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `msg_id` int NOT NULL AUTO_INCREMENT,
  `incoming_msg_id` int NOT NULL,
  `outgoing_msg_id` int NOT NULL,
  `group_id` int DEFAULT NULL,
  `msg` varchar(1000) COLLATE utf8mb4_bin NOT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `date` datetime(6) NOT NULL,
  `read_status` tinyint(1) DEFAULT '0',
  `msg_type` enum('text','image','file') COLLATE utf8mb4_bin NOT NULL DEFAULT 'text',
  `file_name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`msg_id`, `incoming_msg_id`, `outgoing_msg_id`, `group_id`, `msg`, `is_read`, `role`, `date`, `read_status`, `msg_type`, `file_name`) VALUES
(1, 0, 1441627178, 8, '😋😋😋', NULL, '', '2025-03-18 21:56:26.000000', 0, 'text', NULL),
(2, 0, 1441627178, 9, 'bonjou', NULL, '', '2025-03-18 22:10:59.000000', 0, 'text', ''),
(3, 0, 1441627178, 9, '', NULL, '', '2025-03-18 22:11:17.000000', 0, 'text', ''),
(4, 0, 1441627178, 9, 'fgfggf', NULL, '', '2025-03-18 22:16:59.000000', 0, 'text', NULL),
(5, 0, 1441627178, 8, 'ddd', NULL, '', '2025-03-18 22:24:08.000000', 0, 'text', NULL),
(6, 0, 1441627178, 9, 'fff', NULL, '', '2025-03-18 22:28:13.000000', 0, 'text', NULL),
(7, 0, 1441627178, 9, 'vv', NULL, '', '2025-03-18 22:29:05.000000', 0, 'text', NULL),
(8, 0, 1441627178, 9, 'gg', NULL, '', '2025-03-18 22:29:30.000000', 0, 'text', NULL),
(9, 0, 1441627178, 9, 'cc', NULL, '', '2025-03-18 22:29:45.000000', 0, 'text', NULL),
(10, 0, 1441627178, 9, 'tt', NULL, '', '2025-03-18 22:29:58.000000', 0, 'text', NULL),
(11, 0, 1441627178, 9, 'j', NULL, '', '2025-03-18 22:44:39.000000', 0, 'text', NULL),
(12, 0, 1441627178, 9, 'dff', NULL, '', '2025-03-18 22:45:39.000000', 0, 'text', NULL),
(13, 0, 1441627178, 9, 'bvbb', NULL, '', '2025-03-18 22:50:14.000000', 0, 'text', NULL),
(14, 0, 1441627178, 9, 'bvb', NULL, '', '2025-03-18 22:50:28.000000', 0, 'text', NULL),
(15, 0, 1441627178, 9, 'bvbhjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', NULL, '', '2025-03-18 22:50:47.000000', 0, 'text', NULL),
(16, 0, 1441627178, 1, 'bsr', NULL, '', '2025-03-19 15:48:25.000000', 0, 'text', NULL),
(17, 0, 1441627178, 1, 'bsr', NULL, '', '2025-03-19 15:49:05.000000', 0, 'text', NULL),
(18, 0, 1014598516, 11, 'salut', NULL, '', '2025-03-19 16:49:18.000000', 0, 'text', NULL),
(19, 1332942912, 1132293541, NULL, 'yo', NULL, '', '2025-03-20 20:37:46.000000', 0, 'text', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `unique_id` int NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `reset_code` varchar(6) DEFAULT NULL,
  `code_expiry` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `unique_id`, `fname`, `lname`, `email`, `password`, `img`, `status`, `reset_code`, `code_expiry`) VALUES
(1, 1601527834, 'toya', 'jol', 'gb@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1741347893WIN_20241220_14_25_11_Pro.jpg', 'En ligne', NULL, NULL),
(2, 1441627178, 'joel', 'toya', 'stella@gmail.com', 'c23c6cd0e89ee1041b71e4f0a5ccced2', 'WIN_20240724_09_53_04_Pro.jpg', 'Hors ligne', NULL, NULL),
(3, 552497728, 'st', 'toya', 'toy@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1741350063WhatsApp Image 2024-12-25 à 11.25.28_dd387231.jpg', 'En ligne', NULL, NULL),
(4, 1332942912, 'toya', 'sorel', 'joel@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'WIN_20240724_09_53_04_Pro.jpg', 'Hors ligne', NULL, NULL),
(5, 1101274758, 'jj', 'tt', 'jj@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1741706691WIN_20241226_16_35_51_Pro.jpg', 'Hors ligne', NULL, NULL),
(6, 446100033, 'toto', 'toto', 'toto@gmail.com', '024d7f84fff11dd7e8d9c510137a2381', 'WIN_20241220_14_25_11_Pro.jpg', 'Hors ligne', NULL, NULL),
(7, 1461853210, 'lazano', 'joel', 'toyatankwajoelsorel@gmail.com', '68053af2923e00204c3ca7c6a3150cf7', '1741706992WIN_20241220_14_24_44_Pro.jpg', 'Hors ligne', NULL, NULL),
(8, 707344915, 'ttrt', 'rr', 're@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1741707302WIN_20241220_14_25_11_Pro.jpg', 'Hors ligne', NULL, NULL),
(9, 1335120154, '6740565', '16', 're5@gmail.com', 'ddb30680a691d157187ee1cf9e896d03', '1741707423WIN_20241220_14_25_11_Pro.jpg', 'Hors ligne', NULL, NULL),
(10, 1316897058, 'YANN ici ', 't', 'yannick@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1741839932WIN_20241220_14_24_01_Pro.jpg', 'En ligne', NULL, NULL),
(11, 1659151310, 'rt', 'toya', 'rt@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1741967336WIN_20241220_14_24_44_Pro.jpg', 'En ligne', NULL, NULL),
(12, 511427538, 'stella', 'kevine', 'toy2@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1742092972WIN_20241223_15_53_29_Pro.jpg', 'En ligne', NULL, NULL),
(13, 1189816813, 'papa', 'merlin', 'papa@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1742215348WIN_20241220_14_18_23_Pro.jpg', 'En ligne', NULL, NULL),
(14, 1014598516, 'YANN ici ', 't', 'yan-nick@gmail.com', '25d55ad283aa400af464c76d713c07ad', '1742399279WIN_20241220_14_18_23_Pro.jpg', 'Hors ligne', NULL, NULL),
(15, 1379358325, 'sandje', 'marcel', 'marcel@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '1742499416WIN_20241220_14_24_01_Pro.jpg', 'En ligne', NULL, NULL),
(16, 1132293541, 'sandje', 'marcel', 'lazanosorel@gmail.com', '884ce4bb65d328ecb03c598409e2b168', '1742499428WIN_20241220_14_24_01_Pro.jpg', 'En ligne', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
