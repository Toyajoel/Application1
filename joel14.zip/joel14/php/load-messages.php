<?php
session_start();
include_once "config.php";

if (!isset($_SESSION['unique_id']) || !isset($_GET['group_id'])) {
    exit();
}

$group_id = intval($_GET['group_id']);
$messages = mysqli_query($conn, "SELECT * FROM messages WHERE group_id = $group_id");

if ($messages) {
    while ($message = mysqli_fetch_assoc($messages)) {
        echo '<div class="message">';
        echo '<strong>' . htmlspecialchars($message['user_id']) . ':</strong>';
        echo '<p>' . htmlspecialchars($message['content']) . '</p>';
        echo '</div>';
    }
} else {
    echo "Erreur lors de la récupération des messages.";
}
?>