<?php
session_start();
include_once "config.php"; // Inclure la configuration de la base de données

function uploadFile($file, $incoming_id, $outgoing_id) {
    global $conn; // Accéder à la variable de connexion

   if (!empty($file['name'])) {
    $fileName = time() . '_' . basename($file['name']); // Préfixer le nom de fichier avec le timestamp
    $fileTmpName = $file['tmp_name'];
    $filePath = "../uploads/" . $fileName; // Dossier pour stocker le fichier

    // Déplacer le fichier téléchargé vers le dossier de destination
    if (move_uploaded_file($fileTmpName, $filePath)) {
        // Insérer le chemin du fichier dans la base de données
        $sql = "INSERT INTO messages (incoming_msg_id, outgoing_msg_id, file_path, date) 
                VALUES (?, ?, ?, NOW())"; // Assurez-vous que file_path est le bon champ
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "iis", $incoming_id, $outgoing_id, $fileName); // Passer juste le nom du fichier
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            return true; // Retourne vrai si l'insertion réussit
        } else {
            echo "Erreur lors de la préparation de la requête : " . mysqli_error($conn);
        }
    } else {
        echo "Erreur lors du téléchargement du fichier.";
        return false; // Retourne faux en cas d'échec du téléchargement
    }
}
}
?>