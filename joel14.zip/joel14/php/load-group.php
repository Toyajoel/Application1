<?php
session_start();
include_once "config.php";

if (!isset($_SESSION['unique_id'])) {
    echo json_encode(["error" => "Utilisateur non connecté."]);
    exit();
}

$user_id = $_SESSION['unique_id'];

// Requête pour récupérer les groupes où l'utilisateur est soit le créateur, soit un membre
$sql = mysqli_query($conn, "
    SELECT g.* 
    FROM groupes g 
    LEFT JOIN group_users gu ON g.group_id = gu.group_id 
    WHERE gu.user_id = $user_id OR g.creer_par = $user_id
");
$groups = [];

if ($sql) {
    while ($row = mysqli_fetch_assoc($sql)) {
        $groups[] = $row; // Ajoute chaque groupe au tableau
    }

    // Vérifie si des groupes ont été trouvés
    if (empty($groups)) {
        echo json_encode(["message" => "Aucun groupe trouvé."]);
    } else {
        echo json_encode($groups);
    }
} else {
    echo json_encode(["error" => "Erreur lors de la récupération des groupes : " . mysqli_error($conn)]);
}
?>