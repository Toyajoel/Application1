<?php 
session_start();
include_once "php/config.php";
if (!isset($_SESSION['unique_id'])) {
    header("location: login.php");
}
?>
<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="chat-area">
      <header>
        <?php 
          $user_id = mysqli_real_escape_string($conn, $_GET['user_id']);
          $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$user_id}");
          if (mysqli_num_rows($sql) > 0) {
              $row = mysqli_fetch_assoc($sql);

              // Réinitialiser le compteur de messages non lus
              mysqli_query($conn, "UPDATE users SET unread_count = 0 WHERE unique_id = {$user_id}");
          } else {
              header("location: users.php");
          }
        ?>

        <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
        <img src="php/images/<?php echo $row['img']; ?>" alt="">
        <div class="details">
          <span><?php echo $row['fname']. " " . $row['lname']; ?></span>
          <p><?php echo $row['status']; ?></p>
        </div>
      </header>
      <div class="chat-box">
        <!-- Les messages apparaîtront ici -->
      </div>
      <form action="php/insert-chat.php" class="typing-area" enctype="multipart/form-data">
        <input type="text" class="incoming_id" name="incoming_id" value="<?php echo $user_id; ?>" hidden>
        
        <button type="button" class="file-btn" id="fileButton"><i class="fas fa-paperclip"></i></button>
        <div class="file-options" style="display: none;">
            <button type="button" id="documentButton">Document</button>
            <button type="button" id="photoButton">Photo</button>
            <input type="file" id="fileInput" name="message" style="display: none;" />
        </div>
        
        <input type="text" name="message" class="input-field" id="messageInput" placeholder="Taper un message ici..." autocomplete="off">
        <button type="submit"><i class="fab fa-telegram-plane"></i></button>
        <button type="button" id="voiceButton"><i class="fas fa-microphone"></i></button>
      </form>
    </section>
  </div>

  <script src="javascript/chat.js"></script>
  
 
</body>
</html>