<?php 
session_start();
if (isset($_SESSION['unique_id'])) {
    include_once "config.php";
    $outgoing_id = $_SESSION['unique_id'];
    $incoming_id = mysqli_real_escape_string($conn, $_POST['incoming_id']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    
    // Vérifiez si un fichier image a été envoyé
    if (isset($_FILES['send_image']) && $_FILES['send_image']['error'] == UPLOAD_ERR_OK) {
        $send_image = $_FILES['send_image']['name'];
        $send_image_tmp_name = $_FILES['send_image']['tmp_name'];
        $image_folder = 'uploaded_img/' . basename($send_image);

        // Vérifiez la taille et le type de l'image
        $image_size = $_FILES['send_image']['size'];
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

        if ($image_size > 2000000) { // Limite à 2 Mo
            die("La taille de l'image est trop grande !");
        }

        $image_extension = strtolower(pathinfo($send_image, PATHINFO_EXTENSION));
        if (!in_array($image_extension, $allowed_extensions)) {
            die("Type de fichier non autorisé !");
        }

        // Déplacer le fichier téléchargé
        if (move_uploaded_file($send_image_tmp_name, $image_folder)) {
            // Insertion de l'image dans la base de données
            $sql = mysqli_query($conn, "INSERT INTO messages (incoming_msg_id, outgoing_msg_id, msg_img, date, read_status) 
                                        VALUES ({$incoming_id}, {$outgoing_id}, '{$send_image}', NOW(), 0)");
        } else {
            die("Erreur lors du téléchargement de l'image.");
        }
    } elseif (!empty($message)) {
        // Insertion du message texte dans la base de données
        $sql = mysqli_query($conn, "INSERT INTO messages (incoming_msg_id, outgoing_msg_id, msg, date, read_status) 
                                    VALUES ({$incoming_id}, {$outgoing_id}, '{$message}', NOW(), 0)");
    }

    if (!$sql) {
        die("Erreur lors de l'insertion du message : " . mysqli_error($conn));
    }

    // Incrémenter le compteur de messages non lus pour le destinataire
    $updateUnreadCount = mysqli_query($conn, "UPDATE users SET unread_count = unread_count + 1 
                                              WHERE unique_id = {$incoming_id}");

    if (!$updateUnreadCount) {
        die("Erreur lors de la mise à jour du compteur de messages non lus : " . mysqli_error($conn));
    }
} else {
    header("location: ../login.php");
}
?>